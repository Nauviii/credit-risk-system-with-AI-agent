"""Real-time inference API."""
